InfraCraft 모드팩 2026.10.29 (Minecraft 26.2, Fabric Loader 0.20.1)

설치: CurseForge 앱, Prism Launcher, ATLauncher 에서 이 zip 을 '모드팩 가져오기(Import)' 하세요.
  - manifest.json 의 모드는 런처가 CurseForge 에서 받습니다.
  - overrides/mods 의 모드는 zip 에 들어 있습니다(라이선스가 재배포를 허락하는 것).

CurseForge 에서 받는 모드:

zip 에 들어 있는 모드(라이선스):
  fabric-api: Apache-2.0  소스: https://github.com/FabricMC/fabric-api
  fabric-language-kotlin: Apache-2.0  소스: https://github.com/FabricMC/fabric-language-kotlin/
  create: CC0-1.0  소스: https://github.com/ZurrTum/Create-Fly
  railways: GPL-3.0-only  소스: https://github.com/cat4blep/Create-Steam-n-Rails-Fly
  createaddition: MIT  소스: https://github.com/chaevsfe/createaddition
  createdieselgenerators: MIT  소스: https://github.com/chaevsfe/Create-Diesel-Generators
  powergrid: Apache-2.0  소스: https://github.com/chaevsfe/PowerGrid
  electro_energetics: MIT  소스: https://github.com/cat4blep/Creaty-fly-Electro-Energetics
  create_connected: AGPL-3.0  소스: https://github.com/GravisLudio/create-connected-fly
  hypertube: Apache-2.0  소스: https://github.com/meakaandre-tech/CreateHypertubes
  alloyed: MIT  소스: https://github.com/cassiancc/Alloyed
  create_cyber_goggles: MIT  소스: https://github.com/ForgeStove/CreateCyberGoogles
  gravis_flying_config: MIT  소스: https://github.com/GravisLudio/gravis-flying-config-menu

찾지 못했거나 직접 받아야 하는 모드:
  createnuclear: https://github.com/GravisLudio/create-nuclear-fly-26.2
  copycats: ARR(원작 팀 허가 포트): 직접 받아 설치하세요
  bits_n_bobs: https://github.com/zoom-packers/Create-Bits-n-Bobs
  create_dragons_plus: https://www.curseforge.com/minecraft/mc-mods/create-dragons-plus-fly
  create_enchantment_industry: https://www.curseforge.com/minecraft/mc-mods/create-enchantment-industry-fly
  bellsandwhistles: https://github.com/zoom-packers/BellsAndWhistlesMod
  create_central_kitchen: https://github.com/GravisLudio/create-central-kitchen-fly-26.2
  createdeco: https://www.curseforge.com/minecraft/mc-mods/create-fly-deco
  blocks_bogies: https://www.curseforge.com/minecraft/mc-mods/create-fly-blocks-bogies
  gravis_flying_hotfixes: https://github.com/GravisLudio/gravis-flying-hotfixes
